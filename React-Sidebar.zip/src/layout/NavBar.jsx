import React from 'react'

const NavBar = () => {
  return (
    <div className='flex w-full h-[50px] bg-red-100'>NavBar</div>
  )
}

export default NavBar